# My First Project > 2025-07-17 11:43pm
https://universe.roboflow.com/ysl-lh7kb/my-first-project-f1pq8

Provided by a Roboflow user
License: CC BY 4.0

